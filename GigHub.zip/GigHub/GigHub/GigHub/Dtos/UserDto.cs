﻿namespace GigHub.Dtos
{
    public class UserDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}