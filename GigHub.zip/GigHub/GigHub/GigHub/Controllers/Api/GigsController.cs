﻿using GigHub.Models;
using System.Data.Entity;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GigHub.Controllers.Api
{
    [Authorize]
    public class GigsController : ApiController
    {
        private ApplicationDbContext _context;

        public GigsController()
        {
            _context = new ApplicationDbContext();
        }

        [HttpDelete]
        public IHttpActionResult Cancel(int id)
        {
            /*
             * Comment 1)
             * If we want to use "Include()" method with lambda expression
             * we should always include the "using System.Data.Entity;"
             * 
             * Comment 2)
             * Since "Attendances" in the "Include()" method is a collection
             * & "Attendee" is not a property of this collection, therefore we 
             * should use a "Select()" method to select the Attendees.
            */
            var userId = User.Identity.GetUserId();
            var gig = _context.Gigs
                .Include(g => g.Attendances.Select(a => a.Atendee))
                .Single(g => g.Id == id && g.ArtistId == userId);

            // Checks if the gig has been remove earlier
            if (gig.IsCanceled)
                return NotFound();

            // "gig" is the "Gig" class
            gig.Cancel();
            
            _context.SaveChanges();

            return Ok();
        }
    }
}
